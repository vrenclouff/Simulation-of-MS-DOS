#pragma once


bool Init_IDT();