#pragma once

#include "../api/hal.h"

void __stdcall VGA_Handler(kiv_hal::TRegisters &context);